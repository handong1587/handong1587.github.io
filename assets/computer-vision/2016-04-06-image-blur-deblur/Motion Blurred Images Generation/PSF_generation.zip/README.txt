Please refer to this work:

Modeling the Performance of Image Restoration from Motion Blur 
Giacomo Boracchi and Alessandro Foi, Image Processing, IEEE Transactions on. vol.21, no.8, pp. 3502 - 3517, Aug. 2012, doi:10.1109/TIP.2012.2192126 

Preprint available at http://home.dei.polimi.it/boracchi/publications.html 